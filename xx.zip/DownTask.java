package ssl.single;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import thread.threadpool.task.Task;

import com.http.proxy.ANALYSE;
import com.http.proxy.Main;

import email.interfaces.head.DataHeader;

public class DownTask extends Task {

	X509TrustManager x509TrustManager = new X509TrustManager() {

		public X509Certificate[] getAcceptedIssuers() {

			return null;
		}

		public void checkServerTrusted(X509Certificate[] arg0, String arg1)
				throws CertificateException {

		}

		public void checkClientTrusted(X509Certificate[] arg0, String arg1)
				throws CertificateException {

		}
	};

	SSLContext context;
	String taskurl;
	SSLSocketFactory factory;

	public DownTask(String taskurl) {
		this.taskurl = taskurl;
		try {
			context = SSLContext.getInstance("TLS");

			context.init(null, new TrustManager[] { x509TrustManager }, null);

			factory = context.getSocketFactory();
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public boolean work() {
		boolean success = false;
		while (!success) {
			try {
				down(taskurl);
				success = true;
			} catch (Exception e) {
			}
		}
		return true;
	}

	public void down(String url) throws Exception {
		String flord = "D:/Program Files/java软件/maven/mave远程仓库/"
				+ url.replaceAll(
						"https://repository.apache.org/content/groups/public",
						"content/groups/maven-staging-group");
		File file = new File(flord);
		if (file.exists()) {
			return;
		}
		// System.out.println(file);
		if (!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
		}
		SSLSocket socket = null;
		InputStream inPutStream = null;
		FileOutputStream fileOUt = null;
		try {
			socket = (SSLSocket) factory.createSocket();

			// socket.bind(arg0)
			// 10.137.17.192:8227
			socket.connect(new InetSocketAddress("repository.apache.org", 443),
					3000);
			socket.setSoTimeout(30000);
			// 也可以通过这样方式获取 socket.getSession().getPeerCertificates()
			socket.startHandshake();
			OutputStream outPutStream = socket.getOutputStream();
			outPutStream.write(("GET " + url + " HTTP/1.0\r\n").getBytes());

			outPutStream.write("Content-Length: 0\r\n\r\n".getBytes());
			outPutStream.flush();
			inPutStream = socket.getInputStream();

			String contentLength = null;
			boolean chunked = false;
			boolean closed = false;

			// 接收Server 响应
			String statusLine = Main.readLine(inPutStream);

			// 真实目标IP
			contentLength = null;
			chunked = false;
			String headLine = null;
			// 完整的请求信息
			while ((headLine = Main.readLine(inPutStream)) != null) {
				if (headLine.equals("")) {
					break;
				}

				DataHeader currentHead = new DataHeader(headLine);

				if ("Content-length".equalsIgnoreCase(currentHead
						.getHeaderName())) {
					contentLength = currentHead.getHeaderValue().getValue()
							.trim();
				}

				if ("Transfer-Encoding".equalsIgnoreCase(currentHead
						.getHeaderName())
						&& "chunked".equalsIgnoreCase(currentHead
								.getHeaderValue().getValue().trim())) {
					chunked = true;
				}
				if ("Connection".equalsIgnoreCase(currentHead.getHeaderName())
						&& "close".equalsIgnoreCase(currentHead
								.getHeaderValue().getValue().trim())) {
					closed = true;
				}
			}

			ANALYSE analyseMode = ANALYSE.other;
			if (contentLength != null) {
				analyseMode = ANALYSE.contentlength;
			} else if (chunked) {
				analyseMode = ANALYSE.chunked;
			} else if (closed) {
				analyseMode = ANALYSE.close;
			}
			fileOUt = new FileOutputStream(flord);
			final FileOutputStream x = fileOUt;
			ByteArrayOutputStream out = new ByteArrayOutputStream() {
				@Override
				public void write(byte[] b) throws IOException {
					x.write(b);
				}
			};
			if (statusLine.toUpperCase().contains("200")
					|| analyseMode != ANALYSE.other)
				Main.analyzeEntity(
						contentLength == null ? 0 : Integer
								.parseInt(contentLength), inPutStream, out,
						analyseMode, fileOUt);
			out.close();
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				fileOUt.close();
			} catch (Exception e) {

			}
			try {
				inPutStream.close();
			} catch (Exception e) {

			}
			try {
				socket.close();
			} catch (Exception e) {

			}
			System.gc();
		}

	}

	public void unwork() {

	}

	public static String readLine(InputStream in) throws Exception {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		int temp = 1;
		int before = 1;
		while (temp != -1) {
			temp = in.read();
			out.write(temp);

			if ('\n' == temp && '\r' == before) {
				String message = new String(out.toByteArray(), "UTF-8")
						.replaceAll("\r\n", "");
				return message;
			}
			before = temp;
		}

		throw new EOFException("");
	}

}
