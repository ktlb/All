package net_test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.FileNameMap;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.Set;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;

import org.junit.Test;










import proxy.ProxyServer;
import ssl.SSLContextInitializer;
import utils.HttpUtils;

public class HttpTest {

	/**
	 * ����readLine����
	 */
	@Test
	public void test1(){
		try {
			ServerSocket serverSocket = new ServerSocket(3355);
			Socket socket = null;int i=0;
			while ((socket = serverSocket.accept()) != null) {
				i++;
				InputStream in = socket.getInputStream();
				OutputStream out = socket.getOutputStream();
				String line = null;
				while (true) {
					if("".equals(line = HttpUtils.readLine(in))){
						System.out.println("�ָ���");
						break;
					}
					System.out.println(line);
				}
//				in.close();
//				 in.read(b);
//				 System.out.println(new String(b));
				 out.write("HTTP/1.1 200 This is a test!\r\n".getBytes());
				 out.write("Date: Sat, 20 Jun 2015 19:10:59 GMT\r\n".getBytes());
				 out.write("Content-Type: text/html;charset=utf-8\r\n"
				 .getBytes());
				 out.write("\r\n".getBytes());
				 out.write(("��"+i+"��").getBytes("utf-8"));
				 out.flush();
//				 out.close();
				 socket.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * �������� ProxyServer
	 */
	@Test
	public void test2(){
		try {
			ServerSocket serverSocket = new ServerSocket();
			serverSocket.bind(new InetSocketAddress("0.0.0.0",3355));
			Socket socket = null;
			while((socket = serverSocket.accept())!=null){
				new Thread(new ProxyServer(socket)).start();;
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		try {
			ServerSocket serverSocket = new ServerSocket();
			serverSocket.bind(new InetSocketAddress("0.0.0.0",8080));
//			new Thread(){
//				public void run() {
//					Map<Thread,StackTraceElement[]> map=Thread.getAllStackTraces();
//					Set<Thread> set = map.keySet();
//					for(Thread t :set ){
//						System.out.println(t.getState());
//					}
//				};
//			}.start();
			Socket socket = null;
			while((socket = serverSocket.accept())!=null){
				new Thread(new ProxyServer(socket)).start();;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * ����jdk1.7�Դ���mime����  2�ֶ���ȫ��
	 * @throws IOException 
	 */
	@Test
	public void test3() throws IOException{
		FileNameMap fileNameMap = URLConnection.getFileNameMap();
		String contentTypeFor1 = fileNameMap.getContentTypeFor("c:\\dasdas\\sdas.lib");
		String contentTypeFor2 = fileNameMap.getContentTypeFor("xzc.rar");  //null
		String contentTypeFor3 = fileNameMap.getContentTypeFor("sdas.zip");
		String type1 = Files.probeContentType(Paths.get("xxx.rar"));
		String type2 = Files.probeContentType(Paths.get("xxx.zip"));
		String type3 = Files.probeContentType(Paths.get("xxx.jpg"));
		String type4 = Files.probeContentType(Paths.get("xxx.exe"));
		System.out.println(contentTypeFor1);
		System.out.println(contentTypeFor2);
		System.out.println(contentTypeFor3);
		System.out.println(type1);
		System.out.println(type2);
		System.out.println(type3);
		System.out.println(type4);
	}
	
	/**
	 * ����Inetsocketaddress ����Ҫhttp:// ��������Э���
	 * @throws IOException
	 */
	@Test
	public void test4() throws IOException{
		Socket socket = new Socket();
//		socket.connect(new InetSocketAddress("www.baidu.com", 443));
		socket.connect(new InetSocketAddress("www.baidu.com", 80));
		socket.setSoTimeout(5000);
		OutputStream out = socket.getOutputStream();
		InputStream in = socket.getInputStream();
//		out.write("CONNECT www.baidu.com:443 HTTP/1.1\r\n".getBytes());
		out.write("GET / HTTP/1.1\r\n".getBytes());
//		out.write("Host:www.baidu.com:443\r\n".getBytes());
		out.write("Host:www.baidu.com:80\r\n".getBytes());
		out.write("User-Agent:Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0\r\n".getBytes());
		out.write("Connection:keep-alive\r\n".getBytes());
		out.write("\r\n".getBytes());
		out.flush();
		int i;
		FileOutputStream f = new FileOutputStream("C:\\Users\\Administrator\\Desktop\\xx.html");
		while( (i = in.read())!=-1){
			f.write(i);
		}
		f.flush();f.close();
		socket.close();
	}
	
	/**
	 * ����sslcontext
	 * @throws IOException
	 * @throws Exception 
	 */
	@Test
	public void test5() throws IOException, Exception{
		SSLContext ssl = SSLContext.getInstance("SSL");
		ssl.init(null, null, null);
		SSLParameters p = ssl.getDefaultSSLParameters();//Ĭ����TLSv1
		for(String s:p.getProtocols()){
			System.out.println(s);
		}
		
		SSLContext tls = SSLContext.getInstance("TLS");
		tls.init(null, null, null);
		SSLParameters p2 = tls.getDefaultSSLParameters();//Ĭ����TLSv1  ,�����һ��clone����,�޸��˲���Ӧ����������
		for(String s:p2.getProtocols()){
			System.out.println(s);
		}
		System.out.println("-----------");
		for(String s :tls.getSupportedSSLParameters().getProtocols()){
			System.out.println(s);
		}
		
	}
	
}

