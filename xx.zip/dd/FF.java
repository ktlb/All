package ssl.single;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import thread.threadpool.pool.ThreadPool;

import com.http.proxy.ANALYSE;
import com.http.proxy.Main;

import email.interfaces.head.DataHeader;

/**
 * SSL 的客户端. 后面会改成双向认证.
 * 
 * @author gongxu
 * 
 */
public class FF {

	static ThreadPool pool = new ThreadPool(false, 50, 300, 50, 9999999, "", 5,
			50000);

	public static void main(String[] args) throws Exception {
		pool.start();
		new FF().showinfo("https://repository.apache.org/content/groups/public/");
	}

	SSLContext context = null;
	SSLSocketFactory factory = null;

	public FF() throws Exception {
		context = SSLContext.getInstance("SSL", "SunJSSE");
		// 存储校验 信任manger new NothingTrustManager(x509TrustManager);

		context.init(null, new TrustManager[] { x509TrustManager }, null);

		factory = context.getSocketFactory();
	}

	X509TrustManager x509TrustManager = new X509TrustManager() {

		public X509Certificate[] getAcceptedIssuers() {
			// TODO Auto-generated method stub
			return null;
		}

		public void checkServerTrusted(X509Certificate[] arg0, String arg1)
				throws CertificateException {
			// TODO Auto-generated method stub

		}

		public void checkClientTrusted(X509Certificate[] arg0, String arg1)
				throws CertificateException {
			// TODO Auto-generated method stub

		}
	};

	public void showinfo(String rootpath) throws Exception {

		while (pool.getQueue().size() >= 500) {
			Thread.sleep(3000);
		}
		SSLSocket socket = (SSLSocket) factory.createSocket();
		try {
			if (!rootpath.matches("https://repository.apache.org/content/.*")) {
				System.out.println(rootpath);
				System.out.println("return");
				return;
			}

			socket.setSoTimeout(30000);
			// socket.bind(arg0)
			// 10.137.17.192:8227
			socket.connect(new InetSocketAddress("repository.apache.org", 443),
					3000);
			socket.startHandshake();
			OutputStream outPutStream = socket.getOutputStream();
			outPutStream
					.write(("GET " + rootpath + " HTTP/1.0\r\n").getBytes());

			outPutStream.write("Content-Length: 0\r\n\r\n".getBytes());
			outPutStream.flush();

			InputStream serverIn = socket.getInputStream();

			// 接收Server 响应
			String statusLine = Main.readLine(serverIn);

			// 真实目标IP
			String contentLength = null;
			boolean chunked = false;
			String headLine = null;
			boolean closed = false;

			while ((headLine = Main.readLine(serverIn)) != null) {
				if (headLine.equals("")) {
					break;
				}

				DataHeader currentHead = new DataHeader(headLine);

				if ("Content-length".equalsIgnoreCase(currentHead
						.getHeaderName())) {
					contentLength = currentHead.getHeaderValue().getValue()
							.trim();
				}

				if ("Transfer-Encoding".equalsIgnoreCase(currentHead
						.getHeaderName())
						&& "chunked".equalsIgnoreCase(currentHead
								.getHeaderValue().getValue().trim())) {
					chunked = true;
				}
				if ("Connection".equalsIgnoreCase(currentHead.getHeaderName())
						&& "close".equalsIgnoreCase(currentHead
								.getHeaderValue().getValue().trim())) {
					closed = true;
				}
				// response2ie.write((headLine + "\r\n").getBytes("UTF-8"));
			}

			// response2ie.write("\r\n".getBytes("UTF-8"));
			// 完整的请求信息
			ByteArrayOutputStream2 response2ie = new ByteArrayOutputStream2() {

			};
			ANALYSE analyseMode = ANALYSE.other;
			if (contentLength != null) {
				analyseMode = ANALYSE.contentlength;
			} else if (chunked) {
				analyseMode = ANALYSE.chunked;
			} else if (closed) {
				analyseMode = ANALYSE.close;
			}

			// 尝试解析完成
			if (statusLine.toUpperCase().contains("200")
					|| analyseMode != ANALYSE.other)
				Main.analyzeEntity(
						contentLength == null ? 0 : Integer
								.parseInt(contentLength), serverIn,
						response2ie, analyseMode);

			// close
			try {
				socket.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
			BufferedReader read = new BufferedReader(new InputStreamReader(
					new ByteArrayInputStream(response2ie.get())));
			String templine = null;

			while ((templine = read.readLine()) != null) {
				if (templine.indexOf("<a") > 0) {

					// 往下读取一行
					String next = null;
					if ((next = read.readLine()) != null) {
						if (next.indexOf("a>") > 0) {
							templine = templine.trim() + next.trim();
						}
					}

					// 判断中间是不是包括 </>

					String href = templine.replaceAll(".*href=\"", "")
							.replaceAll("\".*", "");
					if (href.equals("../")) {
						continue;
					}
					if (href.matches(".*/")) {

						while (true) {
							try {
								showinfo(href);
							} catch (Exception e) {
								continue;
							}
							break;
						}
						// .asc
					} else if (href.lastIndexOf(".sha") < 0
							&& href.lastIndexOf(".md5") < 0
							&& href.lastIndexOf(".gz") < 0
							&& href.lastIndexOf(".asc") < 0

					) {
						// System.out.println(href);
						// down it
						// down(href);

						pool.addTask(new DownTask(href));
					}

				}
			}
			
			read.close();
			read = null;
			System.gc();
		} catch (Throwable e) {
			try {
				Thread.sleep(1000);
			} catch (Exception e1) {
				// TODO: handle exception
			}
			System.out.println("retry   " + rootpath);
			try {
				socket.close();
			} catch (Exception e1) {
				// TODO: handle exception
			}
			showinfo(rootpath);
		} finally {
			try {
				socket.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}

}

class ByteArrayOutputStream2 extends ByteArrayOutputStream {
	public ByteArrayOutputStream2() {
		super();
		// TODO Auto-generated constructor stub
	}

	public byte[] get() {
		return buf;
	}
}
